from time import sleep
from adafruit_ble import BLERadio
from adafruit_ble.services.nordic import UARTService
from board import P0_29, P0_31, P1_13, P1_15, LED2_B
from busio import I2C, UART
from adafruit_ssd1306 import SSD1306_I2C
from digitalio import DigitalInOut, Direction

DigitalInOut(LED2_B).direction = Direction.OUTPUT
Display = SSD1306_I2C(128, 64, I2C(P0_31, P0_29))
BLE = BLERadio()
Serial = UART(P1_15, P1_13, baudrate=115200)

Display.rotation = 2
Display.fill(0)
Display.text("Wi-Fi:\n\n\n\nPassword:", 0, 0, True)
Display.text("WeMos\n\nnRF52840", 0, 12, True, size=2)
Display.show()

while Serial.readline() != b"nRF52840":
    pass
Display.fill(1)
Display.show()
for _ in range(2):
    sleep(2)
    Serial.write(b"WeMos")
while True:
    if BLE.connected:
        Display.fill(0)
        Display.text("N-TENS", 0, 0, True, size=3)
        Display.text("Connected", 0, 37, True, size=2)
        Display.show()
        while BLE.connected:
            try:
                Serial.write(BLE.connections[0][UARTService].readline())
            except:
                pass
    else:
        Display.fill(0)
        Display.text("Looking\nfor", 0, 0, True, size=2)
        Display.text("N-TENS", 0, 37, True, size=3)
        Display.show()
        for advertisement in BLE.start_scan():
            if advertisement.complete_name == "N-TENS":
                BLE.connect(advertisement)
                break
        BLE.stop_scan()
