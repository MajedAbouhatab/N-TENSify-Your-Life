#include "app_ble.h"
#include <stdbool.h>
#include <stddef.h>
#include <sys/byteorder.h>
#include <zephyr/types.h>
#include <bluetooth/bluetooth.h>
#include <bluetooth/conn.h>
#include <bluetooth/gatt.h>
#include <bluetooth/hci.h>
#include <bluetooth/uuid.h>
#include <bluetooth/services/nus.h>

static app_ble_event_t m_event_callback = 0;
static app_ble_event_data_t m_event_data;

static bool app_bt_connected = false;
static bool app_button_state;

static const struct bt_data ad[] = {
    BT_DATA_BYTES(BT_DATA_FLAGS, (BT_LE_AD_GENERAL | BT_LE_AD_NO_BREDR)),
    BT_DATA(BT_DATA_NAME_COMPLETE, CONFIG_BT_DEVICE_NAME, sizeof(CONFIG_BT_DEVICE_NAME) - 1),
};

static const struct bt_data sd[] = {
    BT_DATA_BYTES(BT_DATA_UUID128_ALL, BT_UUID_NUS_VAL),
};

static void trigger_event(app_ble_event_type_t event_type) {
  if (m_event_callback) {
    m_event_data.type = event_type;
    m_event_callback(&m_event_data);
  }
}

static void connected(struct bt_conn *conn, uint8_t err) {
  app_bt_connected = true;
  trigger_event(APP_BLE_CONNECTED);
}

static void disconnected(struct bt_conn *conn, uint8_t reason) {
  app_bt_connected = false;
  trigger_event(APP_BLE_DISCONNECTED);
}

static struct bt_conn_cb conn_callbacks = {
    .connected = connected,
    .disconnected = disconnected
};

static struct bt_conn_auth_cb conn_auth_callbacks;

void app_ble_start_advertising(void) {
  bt_le_adv_start(BT_LE_ADV_CONN, ad, ARRAY_SIZE(ad),sd, ARRAY_SIZE(sd));
}

void app_ble_init(app_ble_config_t *config) {
  m_event_callback = config->event_callback;
  bt_conn_cb_register(&conn_callbacks);
bt_enable(NULL);
}