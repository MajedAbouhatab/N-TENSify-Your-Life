#include "app_ble.h"
#include "gui.h"
#include <drivers/gpio.h>

static void on_app_ble_event(app_ble_event_data_t *evt_data) {
  switch (evt_data->type) {
  case APP_BLE_CONNECTED:
    gui_set_bt_state(GUI_BT_STATE_CONNECTED);
    break;
  case APP_BLE_DISCONNECTED:
    gui_set_bt_state(GUI_BT_STATE_ADVERTISING);
    app_ble_start_advertising();
    break;
  }
}

void main(void) {
  app_ble_config_t app_ble_config = {.event_callback = on_app_ble_event};
  app_ble_init(&app_ble_config);
  app_ble_start_advertising();
  gui_set_bt_state(GUI_BT_STATE_ADVERTISING);
  gpio_pin_configure(device_get_binding(DT_GPIO_LABEL(DT_ALIAS(led0), gpios)), DT_GPIO_PIN(DT_ALIAS(led0), gpios), GPIO_OUTPUT_ACTIVE);
  gpio_pin_configure(device_get_binding(DT_GPIO_LABEL(DT_ALIAS(led1), gpios)), DT_GPIO_PIN(DT_ALIAS(led1), gpios), GPIO_OUTPUT_ACTIVE);
  gpio_pin_configure(device_get_binding(DT_GPIO_LABEL(DT_ALIAS(led2), gpios)), DT_GPIO_PIN(DT_ALIAS(led2), gpios), GPIO_OUTPUT_ACTIVE);
  gpio_pin_configure(device_get_binding(DT_GPIO_LABEL(DT_ALIAS(led3), gpios)), DT_GPIO_PIN(DT_ALIAS(led3), gpios), GPIO_OUTPUT_ACTIVE);
  gpio_pin_configure(device_get_binding(DT_GPIO_LABEL(DT_ALIAS(sw3), gpios)), DT_GPIO_PIN(DT_ALIAS(sw3), gpios), GPIO_OUTPUT_INACTIVE);
  while (1) {
    k_sleep(K_MSEC(1000));
  }
}