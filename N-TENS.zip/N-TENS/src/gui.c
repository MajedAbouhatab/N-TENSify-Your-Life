#include "gui.h"
#include <device.h>
#include <drivers/display.h>
#include <drivers/gpio.h>
#include <lvgl.h>
#include <zephyr.h>

// Button pressing macros
#define PressModeButton(beep) ButtonPressed(device_get_binding(DT_GPIO_LABEL(DT_ALIAS(led0), gpios)), DT_GPIO_PIN(DT_ALIAS(led0), gpios), beep)
#define PressSPButton(beep) ButtonPressed(device_get_binding(DT_GPIO_LABEL(DT_ALIAS(led1), gpios)), DT_GPIO_PIN(DT_ALIAS(led1), gpios), beep)
#define PressUpButton(beep) ButtonPressed(device_get_binding(DT_GPIO_LABEL(DT_ALIAS(led2), gpios)), DT_GPIO_PIN(DT_ALIAS(led2), gpios), beep)
#define PressDownButton(beep) ButtonPressed(device_get_binding(DT_GPIO_LABEL(DT_ALIAS(led3), gpios)), DT_GPIO_PIN(DT_ALIAS(led3), gpios), beep)

bool SpeedSelector = true;
int PowerValue = 1, SpeedValue = 1, ModeValue = 0, TimerValue = 0;
char LabelValue[9] = {0};
char *ModeText[] = {"Alternating\nTap", "Shake\nPause", "Long Shake\n Long Pause", "Alternating\nTap", "Shake\nPause", "Alternating\nTap", "Shake\nPause", "Alternating\nTap"};

// Create a message queue for handling external GUI commands
K_MSGQ_DEFINE(m_gui_cmd_queue, sizeof(gui_message_t), 8, 4);

// Define a timer to update the GUI periodically
static void on_gui_blink_timer(struct k_timer *dummy);
K_TIMER_DEFINE(gui_blink_timer, on_gui_blink_timer, NULL);

// Define another timer to track session
static void OnSessionTimer(struct k_timer *dummy);
K_TIMER_DEFINE(SessionTimer, OnSessionTimer, NULL);

lv_obj_t *label_bt_state, *SpeedLabel, *PowerLabel, *ModeLabel1, *ModeLabel2, *TimerLabel, *SpeedSlider, *PowerSlider, *ModeButton, *ResetButton;

LV_FONT_DECLARE(arial_20bold);
LV_FONT_DECLARE(calibri_24b);
LV_FONT_DECLARE(calibri_32b);

LV_IMG_DECLARE(Splash);
LV_IMG_DECLARE(Reset);

// Quick On/Off to make sound and delay for TENS
void Buzz(void) {
  static bool BuzzerLevel;
  for (int i = 0; i < 100; i++) {
    BuzzerLevel = !BuzzerLevel;
    gpio_pin_set(device_get_binding(DT_GPIO_LABEL(DT_ALIAS(sw3), gpios)), DT_GPIO_PIN(DT_ALIAS(sw3), gpios), BuzzerLevel);
    k_sleep(K_MSEC(1));
  }
}

// Sound and delay for TENS when button pressed or slider moved
void ButtonPressed(const struct device *port, gpio_pin_t pin, bool b) {
  gpio_pin_set(port, pin, 0);
  b ? Buzz() : k_sleep(K_MSEC(100));
  gpio_pin_set(port, pin, 1);
  k_sleep(K_MSEC(50));
}

static void set_bt_state(gui_bt_state_t state) {
  bool connected = false;
  switch (state) {
  case GUI_BT_STATE_IDLE:
    k_timer_stop(&gui_blink_timer);
    lv_label_set_text(label_bt_state, "Idle");
    break;
  case GUI_BT_STATE_ADVERTISING:
    k_timer_start(&gui_blink_timer, K_MSEC(500), K_MSEC(500));
    lv_label_set_text(label_bt_state, "Advertising");
    break;
  case GUI_BT_STATE_CONNECTED:
    k_timer_stop(&gui_blink_timer);
    lv_label_set_text(label_bt_state, "Connected");
    connected = true;
    break;
  }
}

static void on_gui_blink_timer(struct k_timer *dummy) {
  static bool blink_state;
  blink_state = !blink_state;
  lv_label_set_text(label_bt_state, blink_state ? "Advertising" : CONFIG_BT_DEVICE_NAME);
}

void gui_set_bt_state(gui_bt_state_t state) {
  static gui_message_t set_bt_state_msg;
  set_bt_state_msg.type = GUI_MSG_SET_BT_STATE;
  set_bt_state_msg.params.bt_state = state;
  k_msgq_put(&m_gui_cmd_queue, &set_bt_state_msg, K_NO_WAIT);
}

static void process_cmd_msg_queue(void) {
  gui_message_t cmd_message;
  while (k_msgq_get(&m_gui_cmd_queue, &cmd_message, K_NO_WAIT) == 0) {
    // Process incoming commands depending on type
    switch (cmd_message.type) {
    case GUI_MSG_SET_STATE:
      break;
    case GUI_MSG_SET_BT_STATE:
      set_bt_state(cmd_message.params.bt_state);
      break;
    }
  }
}

// Handeling sliders and button
static void event_handler(lv_obj_t *obj, lv_event_t event) {
  // Only sliders and button
  if (event == LV_EVENT_VALUE_CHANGED || event == LV_EVENT_PRESSED) {
    // Only button
    if (obj == ModeButton) {
      PressModeButton(true);
      // If more than 7 return to 0
      ModeValue = ModeValue < 7 ? ModeValue + 1 : 0;
      lv_label_set_text(ModeLabel1, ModeText[ModeValue]);
      // Display ASCII letter
      sprintf(LabelValue, "\"%c\"", ModeValue + 65);
      lv_label_set_text(ModeLabel2, LabelValue);
      SpeedSelector = true;
      SpeedValue = 1;
      ResetSliderAndLabel(SpeedSlider, SpeedLabel);
      SpeedSelector = false;
      PowerValue = 1;
      ResetSliderAndLabel(PowerSlider, PowerLabel);
    } else if (obj == ResetButton) {
      Buzz();
      // Reboot
      NVIC_SystemReset();
    } else if (obj == SpeedSlider) {
      if (!SpeedSelector) {
        PressSPButton(false);
        SpeedSelector = true;
      }
      // Change speed until it matches user input
      while (lv_slider_get_value(SpeedSlider) != SpeedValue) {
        if (lv_slider_get_value(SpeedSlider) > SpeedValue) {
          SpeedValue++;
          PressUpButton(true);
        } else {
          SpeedValue--;
          PressDownButton(true);
        }
        sprintf(LabelValue, "%d", SpeedValue);
        lv_label_set_text(SpeedLabel, LabelValue);
        lv_obj_set_pos(SpeedLabel, 35, 35 + (16 * (11 - SpeedValue - 1)));
      }
    } else if (obj == PowerSlider) {
      if (SpeedSelector) {
        PressSPButton(false);
        SpeedSelector = false;
      }
      // Change power until it matches user input
      while (lv_slider_get_value(PowerSlider) != PowerValue) {
        if (lv_slider_get_value(PowerSlider) > PowerValue) {
          PowerValue++;
          PressUpButton(true);
        } else {
          PowerValue--;
          PressDownButton(true);
        }
        sprintf(LabelValue, "%d", PowerValue);
        lv_label_set_text(PowerLabel, LabelValue);
        lv_obj_set_pos(PowerLabel, 275, 35 + (16 * (11 - PowerValue - 1)));
      }
    }
  }
}

void InfoLabel(lv_obj_t *label) {
  lv_label_set_text(label, "Idle");
  lv_label_set_align(label, LV_LABEL_ALIGN_CENTER);
  lv_label_set_long_mode(label, LV_LABEL_LONG_CROP);
  lv_obj_set_pos(label, 0, SpeedSelector ? 5 : 230);
  lv_obj_set_size(label, 320, 30);
}

void ModeLabel(lv_obj_t *label, int Y, char *ModeLabelText[], lv_obj_t *F) {
  lv_label_set_text(label, ModeLabelText);
  lv_label_set_align(label, LV_LABEL_ALIGN_CENTER);
  lv_label_set_long_mode(label, LV_LABEL_LONG_CROP);
  lv_obj_set_pos(label, 0, Y);
  lv_obj_set_size(label, 320, 90);
  lv_obj_set_style_local_text_font(label, LV_LABEL_PART_MAIN, LV_STATE_DEFAULT, F);
  lv_obj_set_style_local_text_color(label, LV_LABEL_PART_MAIN, LV_STATE_DEFAULT, LV_COLOR_BLUE);
}

// To be used when changing mode
void ResetSliderAndLabel(lv_obj_t *slider, lv_obj_t *label) {
  lv_slider_set_value(slider, 1, LV_ANIM_OFF);
  lv_label_set_text(label, "1");
  lv_obj_set_pos(label, SpeedSelector ? 35 : 275, 184);
  lv_obj_set_style_local_text_color(label, LV_LABEL_PART_MAIN, LV_STATE_DEFAULT, LV_COLOR_NAVY);
}

// Used once per slider 
void PlaceSliderAndLabel(lv_obj_t *slider, lv_obj_t *label) {
  lv_slider_set_range(slider, 1, 10);
  lv_slider_set_value(slider, SpeedSelector ? 10 : 1, LV_ANIM_OFF);
  lv_obj_set_size(slider, 60, 204);
  lv_obj_set_adv_hittest(slider, true);
  lv_obj_set_event_cb(slider, event_handler);
  lv_obj_set_pos(slider, SpeedSelector ? 10 : 250, 18);
  lv_obj_set_style_local_pad_all(slider, LV_SLIDER_PART_BG, LV_STATE_DEFAULT, 30);
  lv_obj_set_style_local_pad_all(slider, LV_SLIDER_PART_KNOB, LV_STATE_DEFAULT, 0);
  lv_obj_set_style_local_bg_color(slider, LV_SLIDER_PART_BG, LV_STATE_DEFAULT, SpeedSelector ? LV_COLOR_MAKE(127, 212, 230) : LV_COLOR_MAKE(0, 169, 206));
  lv_obj_set_style_local_bg_color(slider, LV_SLIDER_PART_KNOB, LV_STATE_DEFAULT, SpeedSelector ? LV_COLOR_MAKE(0, 169, 206) : LV_COLOR_MAKE(127, 212, 230));
  lv_obj_set_style_local_bg_color(slider, LV_SLIDER_PART_INDIC, LV_STATE_DEFAULT, SpeedSelector ? LV_COLOR_MAKE(127, 212, 230) : LV_COLOR_MAKE(0, 169, 206));
  lv_obj_set_pos(label, SpeedSelector ? 35 : 275, SpeedSelector ? 33 : 184);
  lv_obj_set_style_local_text_color(label, LV_LABEL_PART_MAIN, LV_STATE_DEFAULT, LV_COLOR_NAVY);
  lv_label_set_align(label, LV_LABEL_ALIGN_CENTER);
  lv_label_set_text(label, SpeedSelector ? "S" : "P");
  lv_obj_set_style_local_text_font(label, LV_LABEL_PART_MAIN, LV_STATE_DEFAULT, &arial_20bold);
}

void gui_run(void) {
  lv_obj_set_style_local_bg_color(lv_scr_act(), LV_OBJ_PART_MAIN, LV_STATE_DEFAULT, LV_COLOR_BLACK);
  lv_task_handler();
  SpeedSlider = lv_slider_create(lv_scr_act(), NULL);
  SpeedLabel = lv_label_create(lv_scr_act(), NULL);
  PlaceSliderAndLabel(SpeedSlider, SpeedLabel);
  label_bt_state = lv_label_create(lv_scr_act(), NULL);
  InfoLabel(label_bt_state);
  SpeedSelector = false;
  PowerSlider = lv_slider_create(lv_scr_act(), NULL);
  PowerLabel = lv_label_create(lv_scr_act(), NULL);
  PlaceSliderAndLabel(PowerSlider, PowerLabel);
  TimerLabel = lv_label_create(lv_scr_act(), NULL);
  InfoLabel(TimerLabel);

  ModeButton = lv_obj_create(lv_scr_act(), NULL);
  lv_obj_set_pos(ModeButton, 80, 48);
  lv_obj_set_size(ModeButton, 160, 144);
  lv_obj_set_style_local_bg_color(ModeButton, LV_OBJ_PART_MAIN, LV_STATE_DEFAULT, LV_COLOR_BLACK);
  lv_obj_set_style_local_border_color(ModeButton, LV_BTN_PART_MAIN, LV_STATE_DEFAULT, LV_COLOR_BLUE);
  lv_obj_set_style_local_border_color(ModeButton, LV_BTN_PART_MAIN, LV_STATE_FOCUSED, LV_COLOR_BLUE);
  lv_obj_set_event_cb(ModeButton, event_handler);

  ModeLabel1 = lv_label_create(lv_scr_act(), NULL);
  ModeLabel(ModeLabel1, 60, ModeText[ModeValue], &calibri_24b);
  ModeLabel2 = lv_label_create(lv_scr_act(), NULL);
  ModeLabel(ModeLabel2, 145, "\"A\"", &calibri_32b);

  lv_obj_t *SplashImage = lv_img_create(lv_scr_act(), NULL);
  lv_img_set_src(SplashImage, &Splash);

  display_blanking_off(device_get_binding(CONFIG_LVGL_DISPLAY_DEV_NAME));
  lv_task_handler();
  PressUpButton(false);
  k_sleep(K_MSEC(2000));
  PressUpButton(true);
  lv_obj_set_hidden(SplashImage, true);
  k_timer_start(&SessionTimer, K_MSEC(0), K_MSEC(1000));

  while (1) {
    process_cmd_msg_queue();
    lv_task_handler();
    k_sleep(K_MSEC(20));
  }
}

static void OnSessionTimer(struct k_timer *dummy) {
  TimerValue++;
  sprintf(LabelValue, "%d:%02d", (TimerValue - TimerValue % 60) / 60 % 60, TimerValue % 60);
  lv_label_set_text(TimerLabel, LabelValue);
  if (TimerValue % 10 == 0) {
    // Time is up
    if (TimerValue >= 900) {
      k_timer_stop(&SessionTimer);
      lv_obj_clean(lv_scr_act());
      k_sleep(K_MSEC(1000));
      sprintf(LabelValue, "%03d-----", TimerValue);
      // Send via BLE
      bt_nus_send(NULL, LabelValue, sizeof(LabelValue));
      ResetButton = lv_imgbtn_create(lv_scr_act(), NULL);
      lv_imgbtn_set_src(ResetButton, LV_BTN_STATE_RELEASED, &Reset);
      lv_imgbtn_set_src(ResetButton, LV_BTN_STATE_PRESSED, &Reset);
      lv_obj_set_event_cb(ResetButton, event_handler);
    } else {
      sprintf(LabelValue, "%03d%02d%c%02d", TimerValue, SpeedValue, ModeValue + 65, PowerValue);
      // Send via BLE
      bt_nus_send(NULL, LabelValue, sizeof(LabelValue));
    }
  }
}

// Define our GUI thread, using a stack size of 4096 and a priority of 7
K_THREAD_DEFINE(gui_thread, 4096, gui_run, NULL, NULL, NULL, 7, 0, 0);